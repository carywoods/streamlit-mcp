import pandas as pd
import streamlit as st

st.set_page_config(page_title="Unit Economics Simulator", layout="centered")
st.title("SaaS Unit Economics Simulator")
st.caption("Adjust pricing and churn assumptions to model ARR and LTV.")

seats = st.number_input(
    "Active Customer Accounts",
    min_value=10,
    max_value=100_000,
    value=250,
    step=10,
    key="accounts",
    help="Total paying customer accounts.",
)
arpa = st.slider(
    "Monthly ARPA ($)",
    min_value=50,
    max_value=2000,
    value=300,
    step=25,
    key="arpa",
    help="Average monthly revenue per account in USD.",
)
monthly_churn = st.slider(
    "Monthly Logo Churn (%)",
    min_value=0.5,
    max_value=15.0,
    value=2.5,
    step=0.5,
    key="churn_pct",
    help="Percentage of accounts canceling each month.",
)

if monthly_churn <= 0:
    st.error("Monthly churn must be greater than 0%.")
    st.stop()

mrr = seats * arpa
arr = mrr * 12
ltv = arpa / (monthly_churn / 100.0)

col1, col2, col3 = st.columns(3)
col1.metric("MRR", f"${mrr:,.0f}")
col2.metric("ARR", f"${arr:,.0f}")
col3.metric("Estimated LTV", f"${ltv:,.0f}")

projection = pd.DataFrame(
    {
        "Month": [1, 3, 6, 12],
        "Projected Revenue ($)": [mrr * m for m in (1, 3, 6, 12)],
    }
)
st.dataframe(projection, hide_index=True)
